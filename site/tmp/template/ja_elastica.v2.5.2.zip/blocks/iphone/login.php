<?php
// no direct access
defined('_JEXEC') or die('Restricted access'); ?>
<jdoc:include type="module" name="login" />